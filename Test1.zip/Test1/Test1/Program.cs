﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    class Program
    {
        static void Main(string[] args)
        {
            CarCollection carC = new CarCollection();
            carC.Sample();

            Car car = new Car();

            foreach(var icars in CarCollection.GetCarCollection().iCar)
            {
                car.Display(icars.Id, icars.brand, icars.model, icars.price, icars.carCondition, icars.productionYear);
            }

            foreach (var pcars in CarCollection.GetCarCollection().pCar)
            {
                car.Display(pcars.Id, pcars.brand, pcars.model, pcars.price, pcars.carCondition, pcars.productionYear);
            }

            Console.ReadLine();
        }
    }
}

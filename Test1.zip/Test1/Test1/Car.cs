﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    public class Car
    {
        public int Id { get; set; }
        public float price { get; set; }
        public Condition carCondition { get; set; }
        public int productionYear { get; set; }

        public void Display(int id, string brand, string model, float price, Condition condition, int productionY)
        {
            Console.WriteLine("Car id: " + id);
            Console.WriteLine("Car brand: " + brand);
            Console.WriteLine("Car model: " + model);
            Console.WriteLine("Car price: " + price);
            Console.WriteLine("Car condition: " + condition);
            Console.WriteLine("Car production year: " + productionY);
        }
        public void Display(string brand, string model, float price, Condition condition, int productionY)
        {
            Console.WriteLine("Car brand: " + brand);
            Console.WriteLine("Car model: " + model);
            Console.WriteLine("Car price: " + price);
            Console.WriteLine("Car condition: " + condition);
            Console.WriteLine("Car production year: " + productionY);
        }
    }
    public enum Condition
    {
        New, 
        Old,
        Used
    }
}

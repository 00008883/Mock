﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    public class CarCollection
    {
        public List<Industrial> iCar { get; set; }
        public List<Passenger> pCar { get; set; }

        public CarCollection()
        {
            iCar = new List<Industrial>();
            pCar = new List<Passenger>();
        }

        private static CarCollection myCarCollection;

        public static CarCollection GetCarCollection()
        {
            if(myCarCollection == null)
            {
                myCarCollection = new CarCollection();
            }
            return myCarCollection;
        }

        public void Sample()
        {
            CarCollection cC = GetCarCollection();
            Passenger pcar1 = new Passenger()
            {
                Id = 111,
                brand = "BMW",
                model = "X5",
                price = 80000,
                productionYear = 2018,
                carCondition = Condition.New
            };
            cC.pCar.Add(pcar1);

            Passenger pcar2 = new Passenger()
            {
                Id = 112,
                brand = "Chevrolet",
                model = "Matiz",
                price = 90000,
                productionYear = 2021,
                carCondition = Condition.New
            };
            cC.pCar.Add(pcar2);

            Industrial icar1 = new Industrial()
            {
                Id = 113,
                brand = "Man",
                model = "X500",
                price = 700000,
                productionYear = 2017,
                carCondition = Condition.Old
            };
            cC.iCar.Add(icar1);

            Industrial icar2 = new Industrial()
            {
                Id = 113,
                brand = "Volvo",
                model = "W500",
                price = 600000,
                productionYear = 2011,
                carCondition = Condition.Used
            };
            cC.iCar.Add(icar2);
        }
    }
}

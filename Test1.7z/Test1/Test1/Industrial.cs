﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    public class Industrial: Car, ICar
    {
        public string brand { get; set; }
        public string model { get; set; }
    }
}
